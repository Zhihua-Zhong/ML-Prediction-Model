package pers.icefrost.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.*;
import pers.icefrost.pojo.User;
import pers.icefrost.service.UserService;

import javax.sql.DataSource;
import java.io.*;
import java.util.List;

@RestController
public class TestController {

    @Autowired
    private DataSource dataSource;
    @Autowired
    private UserService userService;

    @GetMapping("/user/{id}")
    public User queryById(@PathVariable Long id){
        return userService.queryById(id);
    }

    @GetMapping("find")
    public List<User> findAll(){
        return userService.findAll();
    }

    @GetMapping("/save")
    public String saveUser(){
        User user = new User();
        user.setUsername("abc");
        user.setPassword("1232");
        userService.saveUser(user);
        return "add: "+user.getUsername()+user.getId();
    }

    @GetMapping("hello")
    public String test(){
        return "Hello";
    }

    @PostMapping("/registUserServlet")
    @ResponseBody
    public String testPost2(User user) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String json = mapper.writeValueAsString(user);
        /*System.out.println(json);
        writeText("../input.txt", json);
        System.out.println("write succeed");
        StringBuilder res = readText("../input.txt");
        System.out.println(res);
        System.out.println("read succeed");*/
        Process proc = Runtime.getRuntime().exec( "cmd /c python " + "D:\\Projects\\Master projects\\linux-package\\" + "predict.py" );
        System.out.println("one done");
        proc.waitFor();

        return json;
    }
}
