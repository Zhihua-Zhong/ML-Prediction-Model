package pers.icefrost.controller;

import org.json.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import pers.icefrost.pojo.InputData;
import pers.icefrost.pojo.OutputData;
import pers.icefrost.service.DataService;

@RestController
public class DataController {

    @Autowired
    private DataService dataService;

    @PostMapping("/inputData")
    @ResponseBody
    public OutputData predict(InputData inputData) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        String inputStr = mapper.writeValueAsString(inputData);
        return dataService.predict(inputStr);
    }
}
