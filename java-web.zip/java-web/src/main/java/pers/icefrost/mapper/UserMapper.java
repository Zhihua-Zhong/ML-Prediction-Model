package pers.icefrost.mapper;

import pers.icefrost.pojo.User;
import tk.mybatis.mapper.common.Mapper;

public interface UserMapper extends Mapper<User> {
}
