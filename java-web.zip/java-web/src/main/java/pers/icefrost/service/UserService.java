package pers.icefrost.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pers.icefrost.mapper.UserMapper;
import pers.icefrost.pojo.User;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    public User queryById(Long id){
        return userMapper.selectByPrimaryKey(id);
    }

    public List<User> findAll(){
        return userMapper.selectAll();
    }

    @Transactional
    public void saveUser(User user){
        userMapper.insertSelective(user);
    }


}
