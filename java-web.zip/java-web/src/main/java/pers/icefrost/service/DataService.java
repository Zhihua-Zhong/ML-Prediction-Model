package pers.icefrost.service;

import org.json.JSONObject;
import org.springframework.stereotype.Service;
import pers.icefrost.Utils.MyUtils;
import pers.icefrost.pojo.OutputData;

import java.io.InputStream;
import java.util.Objects;

@Service
public class DataService {
    /*  1)save data to input.txt
        2)use python script to do prediction
        3)load prediction result in output.txt
        4)package output data as a pojo class*/
    public OutputData predict(String json) throws Exception {
        String filePath = this.getClass().getResource("/").getPath();
        String Path = filePath.substring(5, filePath.length()-45);
        System.out.println("input file path is : " + Path + "input.txt");
        MyUtils.writeText(Path + "input.txt", json);
        System.out.println("write completed");
        System.out.println("executing : " + "/usr/bin/python3 " + Path + "predict.py");
        Process process = Runtime.getRuntime().exec("/usr/bin/python3 " + Path + "predict.py");
        process.waitFor();
        System.out.println("executed");
        String outputStr = MyUtils.readText(Path + "output.txt");
        System.out.println("output file path is : " + Path + "output.txt");
        JSONObject outputJson = new JSONObject(new String(outputStr));
        OutputData outputData = new OutputData();
        outputData.setMortality((Double) outputJson.get("mortality"));
        outputData.setLiverDysfunction((Double) outputJson.get("liverDysfunction"));
        outputData.setSepticShock((Double) outputJson.get("septicShock"));
        outputData.setThrombocytopenia((Double) outputJson.get("thrombocytopenia"));
        return outputData;
    }
}
