package pers.icefrost.Utils;

import java.io.*;

public class MyUtils {
    public static String readText(String path) throws IOException {
        InputStream inputStream = new FileInputStream(new File(path));
        byte[] b = new byte[128];
        StringBuilder result = new StringBuilder();
        while ((inputStream.read(b))!=-1){
            result.append(new String(b));
        }
        inputStream.close();
        return result.toString();
    }

    public static void writeText(String path, String str) throws IOException {
        OutputStream outputStream = new FileOutputStream(new File(path));
        byte[] b = str.getBytes();
        outputStream.write(b);
        outputStream.close();
    }
}
