package pers.icefrost.pojo;

public class InputData {

    private Integer gender;
    private Integer age;
    private Integer vasopressin;
    private Double urineOutput;
    private Double heartRate;
    private Double sysBP;
    private Double diasBP;
    private Double respiratoryRate;
    private Double temperature;
    private Double spo2;
    private Double baseExcess;
    private Double totalCO2;
    private Double calcium;
    private Double lactate;
    private Double pco2;
    private Double ph;
    private Double po2;
    private Integer coronaryHeartDisease;
    private Integer diabetes;
    private Integer historyOfStroke;
    private Double creatinine;
    private Double glucose;
    private Double platelet;
    private Double potassium;
    private Double sodium;
    private Double ureaNitrogen;
    private Double whiteBloodCell;
    private Double anionGap;
    private Double bicarbonate;
    private Double hematocrit;
    private Double hemoglobin;
    private Double ptt;
    private Double inr;
    private Double pt;
    private Double bmi;

    public Integer getGender() {
        return gender;
    }

    public void setGender(Integer gender) {
        this.gender = gender;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Integer getVasopressin() {
        return vasopressin;
    }

    public void setVasopressin(Integer vasopressin) {
        this.vasopressin = vasopressin;
    }

    public Double getUrineOutput() {
        return urineOutput;
    }

    public void setUrineOutput(Double urineOutput) {
        this.urineOutput = urineOutput;
    }

    public Double getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(Double heartRate) {
        this.heartRate = heartRate;
    }

    public Double getSysBP() {
        return sysBP;
    }

    public void setSysBP(Double sysBP) {
        this.sysBP = sysBP;
    }

    public Double getDiasBP() {
        return diasBP;
    }

    public void setDiasBP(Double diasBP) {
        this.diasBP = diasBP;
    }

    public Double getRespiratoryRate() {
        return respiratoryRate;
    }

    public void setRespiratoryRate(Double respiratoryRate) {
        this.respiratoryRate = respiratoryRate;
    }

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public Double getSpo2() {
        return spo2;
    }

    public void setSpo2(Double spo2) {
        this.spo2 = spo2;
    }

    public Double getBaseExcess() {
        return baseExcess;
    }

    public void setBaseExcess(Double baseExcess) {
        this.baseExcess = baseExcess;
    }

    public Double getTotalCO2() {
        return totalCO2;
    }

    public void setTotalCO2(Double totalCO2) {
        this.totalCO2 = totalCO2;
    }

    public Double getCalcium() {
        return calcium;
    }

    public void setCalcium(Double calcium) {
        this.calcium = calcium;
    }

    public Double getLactate() {
        return lactate;
    }

    public void setLactate(Double lactate) {
        this.lactate = lactate;
    }

    public Double getPco2() {
        return pco2;
    }

    public void setPco2(Double pco2) {
        this.pco2 = pco2;
    }

    public Double getPh() {
        return ph;
    }

    public void setPh(Double ph) {
        this.ph = ph;
    }

    public Double getPo2() {
        return po2;
    }

    public void setPo2(Double po2) {
        this.po2 = po2;
    }

    public Integer getCoronaryHeartDisease() {
        return coronaryHeartDisease;
    }

    public void setCoronaryHeartDisease(Integer coronaryHeartDisease) {
        this.coronaryHeartDisease = coronaryHeartDisease;
    }

    public Integer getDiabetes() {
        return diabetes;
    }

    public void setDiabetes(Integer diabetes) {
        this.diabetes = diabetes;
    }

    public Integer getHistoryOfStroke() {
        return historyOfStroke;
    }

    public void setHistoryOfStroke(Integer historyOfStroke) {
        this.historyOfStroke = historyOfStroke;
    }

    public Double getCreatinine() {
        return creatinine;
    }

    public void setCreatinine(Double creatinine) {
        this.creatinine = creatinine;
    }

    public Double getGlucose() {
        return glucose;
    }

    public void setGlucose(Double glucose) {
        this.glucose = glucose;
    }

    public Double getPlatelet() {
        return platelet;
    }

    public void setPlatelet(Double platelet) {
        this.platelet = platelet;
    }

    public Double getPotassium() {
        return potassium;
    }

    public void setPotassium(Double potassium) {
        this.potassium = potassium;
    }

    public Double getSodium() {
        return sodium;
    }

    public void setSodium(Double sodium) {
        this.sodium = sodium;
    }

    public Double getUreaNitrogen() {
        return ureaNitrogen;
    }

    public void setUreaNitrogen(Double ureaNitrogen) {
        this.ureaNitrogen = ureaNitrogen;
    }

    public Double getWhiteBloodCell() {
        return whiteBloodCell;
    }

    public void setWhiteBloodCell(Double whiteBloodCell) {
        this.whiteBloodCell = whiteBloodCell;
    }

    public Double getAnionGap() {
        return anionGap;
    }

    public void setAnionGap(Double anionGap) {
        this.anionGap = anionGap;
    }

    public Double getBicarbonate() {
        return bicarbonate;
    }

    public void setBicarbonate(Double bicarbonate) {
        this.bicarbonate = bicarbonate;
    }

    public Double getHematocrit() {
        return hematocrit;
    }

    public void setHematocrit(Double hematocrit) {
        this.hematocrit = hematocrit;
    }

    public Double getHemoglobin() {
        return hemoglobin;
    }

    public void setHemoglobin(Double hemoglobin) {
        this.hemoglobin = hemoglobin;
    }

    public Double getPtt() {
        return ptt;
    }

    public void setPtt(Double ptt) {
        this.ptt = ptt;
    }

    public Double getInr() {
        return inr;
    }

    public void setInr(Double inr) {
        this.inr = inr;
    }

    public Double getPt() {
        return pt;
    }

    public void setPt(Double pt) {
        this.pt = pt;
    }

    public Double getBmi() {
        return bmi;
    }

    public void setBmi(Double bmi) {
        this.bmi = bmi;
    }

    @Override
    public String toString() {
        return "InputData{" +
                "gender=" + gender +
                ", age=" + age +
                ", vasopressin=" + vasopressin +
                ", urineOutput=" + urineOutput +
                ", heartRate=" + heartRate +
                ", sysBP=" + sysBP +
                ", diasBP=" + diasBP +
                ", respiratoryRate=" + respiratoryRate +
                ", temperature=" + temperature +
                ", spo2=" + spo2 +
                ", baseExcess=" + baseExcess +
                ", totalCO2=" + totalCO2 +
                ", calcium=" + calcium +
                ", lactate=" + lactate +
                ", pco2=" + pco2 +
                ", ph=" + ph +
                ", po2=" + po2 +
                ", coronaryHeartDisease=" + coronaryHeartDisease +
                ", diabetes=" + diabetes +
                ", historyOfStroke=" + historyOfStroke +
                ", creatinine=" + creatinine +
                ", glucose=" + glucose +
                ", platelet=" + platelet +
                ", potassium=" + potassium +
                ", sodium=" + sodium +
                ", ureaNitrogen=" + ureaNitrogen +
                ", whiteBloodCell=" + whiteBloodCell +
                ", anionGap=" + anionGap +
                ", bicarbonate=" + bicarbonate +
                ", hematocrit=" + hematocrit +
                ", hemoglobin=" + hemoglobin +
                ", ptt=" + ptt +
                ", inr=" + inr +
                ", pt=" + pt +
                ", bmi=" + bmi +
                '}';
    }
}
