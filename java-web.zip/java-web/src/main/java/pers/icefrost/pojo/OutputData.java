package pers.icefrost.pojo;

import java.io.Serializable;

public class OutputData implements Serializable {
    private Double mortality;
    private Double septicShock;
    private Double liverDysfunction;
    private Double thrombocytopenia;

    public Double getMortality() {
        return mortality;
    }

    public void setMortality(Double mortality) {
        this.mortality = mortality;
    }

    public Double getSepticShock() {
        return septicShock;
    }

    public void setSepticShock(Double septicShock) {
        this.septicShock = septicShock;
    }

    public Double getLiverDysfunction() {
        return liverDysfunction;
    }

    public void setLiverDysfunction(Double liverDysfunction) {
        this.liverDysfunction = liverDysfunction;
    }

    public Double getThrombocytopenia() {
        return thrombocytopenia;
    }

    public void setThrombocytopenia(Double thrombocytopenia) {
        this.thrombocytopenia = thrombocytopenia;
    }

    @Override
    public String toString() {
        return "OutputData{" +
                "mortality=" + mortality +
                ", septicShock=" + septicShock +
                ", liverDysfunction=" + liverDysfunction +
                ", thrombocytopenia=" + thrombocytopenia +
                '}';
    }
}
